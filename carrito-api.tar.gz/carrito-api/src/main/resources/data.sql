INSERT INTO productos (nombre, descripcion, precio, stock)
VALUES
('Laptop', 'Laptop Lenovo IdeaPad 15 pulgadas', 799.99, 10),
('Mouse', 'Mouse inalambrico', 25.50, 50),
('Teclado', 'Teclado mecanico', 45.00, 30),
('Monitor', 'Monitor Samsung 24 pulgadas', 189.00, 15),
('USB', 'Memoria USB 64GB', 12.75, 100);