package com.proyecto.carrito.repository;
import com.proyecto.carrito.entity.CarritoItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface CarritoItemRepository extends JpaRepository<CarritoItem, Long> {
}
