package com.proyecto.carrito.controller;

import com.proyecto.carrito.entity.Carrito;
import com.proyecto.carrito.entity.Producto;
import com.proyecto.carrito.service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")

public class CarritoController {
    @Autowired
    private CarritoService carritoService;

    @GetMapping("/catalogo")
    public ResponseEntity<List<Producto>> listarCatalogo() {
        List<Producto> productos = carritoService.obtenerCatalogo();
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }
    @GetMapping("/carrito")
    public ResponseEntity<List<Carrito>> verCarrito() {
        List<Carrito> items = carritoService.obtenerCarrito();
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @PostMapping("/carrito/agregar")
    public ResponseEntity<Carrito> agregarAlCarrito(
            @RequestParam Long productoId,
            @RequestParam Integer cantidad){
        Carrito nuevoItem = carritoService.agregarProducto(productoId, cantidad);
        return new ResponseEntity<>(nuevoItem, HttpStatus.CREATED);
    }

    @DeleteMapping("/carrito/eliminar/{id}")
    public ResponseEntity<String> eliminarDelCarrito(@PathVariable Long id) {
        carritoService.eliminarProducto(id);
        return new ResponseEntity<>("Producto eliminado del carrito con exito", HttpStatus.OK);
    }
}
