package com.proyecto.carrito.service;
import com.proyecto.carrito.entity.Carrito;
import com.proyecto.carrito.entity.CarritoItem;
import com.proyecto.carrito.entity.Producto;
import com.proyecto.carrito.repository.CarritoRepository;
import com.proyecto.carrito.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CarritoService {

    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    public Carrito agregarProducto(Long ProductoId,Integer cantidad){
        Producto producto = productoRepository.findById(ProductoId)
                .orElseThrow(() -> new RuntimeException("El producto solicitado no existe."));

        Optional<Carrito> registroExistente = carritoRepository.findByProductoId(ProductoId);

        if (registroExistente.isPresent()) {
            Carrito carrito = registroExistente.get();
            carrito.setCantidad(carrito.getCantidad() + cantidad);
            return carritoRepository.save(carrito);
        }
        else {
            Carrito nuevoItem = new Carrito();
            nuevoItem.setProducto(producto);
            nuevoItem.setCantidad(cantidad);
            return carritoRepository.save(nuevoItem);
        }
    }

    public void eliminarProducto(Long id) {
        carritoRepository.deleteById(id);
    }

    public  List<Producto> obtenerCatalogo() {
        return productoRepository.findAll();
    }
    public List<Carrito>obtenerCarrito(){
        return
                carritoRepository.findAll();
        }
        public Carrito obtenerCarrito(Long id){
        return
                carritoRepository.findById(id).orElse(null);
    }
}

