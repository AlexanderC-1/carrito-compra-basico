const API_URL = 'http://localhost:8080/api';
async function cargarProductos(){
try{
const resupesta = await fetch('http://localhost:8080/api/productos');

const productos = await resupesta.json();

const contenedor = document.getElementById('lista-productos');
contenedor.innerHTML = '';

productos.forEach(producto=> {
contenedor.innerHTML += `
<div class="producto">
<h3>$ {producto.nombre}</h3>
<p>$ {producto,descripcion}</p>
<p> class="precio">Q ${producto.precio}</p>
<p> Stock:${producto.stock}</p>
<button> onclick="agregarAlCarrito(${producto.id}">Agregar al carrito</button>
</div>
`;
});
} catch (error) {
console.error('Error al cargar productos:', error);
}
}
async function agregarAlCarrto(id){
try {
const respuesta = await fletch(`http://localhost:8080/api/carrito/${id}/agregar`,;
method: 'POST'
});
await respuesta.json();
alert('Producto agregado al carrito');
cargarCarrito();
} catch(error) {
console.error('Error:', error);
alert('No se puede agregar el producto')
}
}
async function cargarCarrito(){
try {
const respuesta = await fetch('http://loclahost:8080/api/carrito');
const items = await respuesta.json();
const contenedor = document.getElementById('carrito-contenido');
contenedor.innerHTML = '';

if (items.length === 0){
contenedor.innerHTML = '<p> Tu carrito està vacio </p>
return;
}

items.forEach(item => {
contenedor.innerHTML +=`<div class="item-carrito">
<p><strong>${item.producto?.nombre || 'producto'}</strong></p>
<p>Cantidad:${item.cantidad}</p>
<p>Subtotal:Q${item.subtotal}</p>
</div>`;

`;
});

} catch (error) {
console.error('Error al cargar el carrito:', error);
}
}
document.addEventListener('DOMContentLoaded', function(){
cargarProductos();
cargarCarrito();
});

